package be.intec.scrumOprdacht.controllers.interfaces;

public interface SignUpController {
}
