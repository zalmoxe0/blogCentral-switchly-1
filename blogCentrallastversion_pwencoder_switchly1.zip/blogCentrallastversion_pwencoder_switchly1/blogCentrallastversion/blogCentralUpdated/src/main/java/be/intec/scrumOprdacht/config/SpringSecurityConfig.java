package be.intec.scrumOprdacht.config;

import be.intec.scrumOprdacht.controllers.interfaces.PasswordEncoderService;
import be.intec.scrumOprdacht.controllers.interfaces.UserController;
import be.intec.scrumOprdacht.models.User;
import be.intec.scrumOprdacht.repositories.UserRepository;
import be.intec.scrumOprdacht.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.*;
import org.springframework.security.crypto.scrypt.SCryptPasswordEncoder;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

//    private final AccessDeniedHandler accessDeniedHandler;

    final DataSource dataSource;

    @Value("${spring.queries.users-query}")
    private String usersQuery;

    @Value("${spring.queries.roles-query}")
    private String rolesQuery;

    @Autowired
    public SpringSecurityConfig(DataSource dataSource) {
//        this.accessDeniedHandler = accessDeniedHandler;
        this.dataSource = dataSource;
    }

    /**
     * HTTPSecurity configurer
     * - roles ADMIN allow to access /admin/**
     * - roles AUTHOR allow to access /author/** and /newPost/**
     * - anybody can visit /, /home, /registration, /post/**
     * - every other page needs authentication
     * - custom 403 access denied handler
     */

    // switchly configure
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception{
        auth.inMemoryAuthentication()
                .passwordEncoder(getPasswordEncoder())
                .withUser("hyperborea")
                .password(getPasswordEncoder().encode("Zamolxis369"))
                .roles(" User");
    }
    // end switchly configure

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.csrf().disable()
                .authorizeRequests()
                .antMatchers("/home", "/signup", "/search", "/posts/view/*","/**").permitAll()
                .antMatchers("/posts/like/*", "/bloghome/*", "/commentPost/*", "/createComment/*").hasAnyRole("Author")
                // .anyRequest().authenticated()
                .anyRequest().hasRole("User")
                .and()
                .formLogin()
                .loginPage("/login")
                .defaultSuccessUrl("/home")
                .permitAll()
                .and()
                .logout()
                .permitAll();
//                .and()
//                .exceptionHandling().accessDeniedHandler(accessDeniedHandler);
                    }


    /**
     * Authentication details
     */



    // switchly PasswordEncoder

    @Bean
    public PasswordEncoder getPasswordEncoder(){
        //return new BCryptPasswordEncoder();
        return new BCryptPasswordEncoder();
}
// end switchly PasswordEncoder

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {

//        // Database authentication
//
//        String idForEncode = "bcrypt";
//        Map<String,PasswordEncoder> encoders = new HashMap<>();
//        encoders.put(idForEncode, new BCryptPasswordEncoder());
//        encoders.put("noop", NoOpPasswordEncoder.getInstance());
//        encoders.put("pbkdf2", new Pbkdf2PasswordEncoder());
//        encoders.put("scrypt", new SCryptPasswordEncoder());
//        encoders.put("sha256", new StandardPasswordEncoder());
//
//        PasswordEncoder DelegatingPasswordEncoder = new DelegatingPasswordEncoder(idForEncode, encoders);

        auth.
                jdbcAuthentication()
                .usersByUsernameQuery(usersQuery)
                .authoritiesByUsernameQuery(rolesQuery)
                .dataSource(dataSource);

    }

    /**
     * Configure and return BCrypt password encoder
     */
   /* @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }*/

}
