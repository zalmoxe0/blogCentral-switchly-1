package be.intec.scrumOprdacht;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogCentralMainApp {

    public static void main(String[] args) {
        SpringApplication.run(BlogCentralMainApp.class, args);

    }

}

