package be.intec.scrumOprdacht.controllers.interfaces;

public interface PasswordEncoderService{
    public abstract String encode(     CharSequence rawPassword );
}